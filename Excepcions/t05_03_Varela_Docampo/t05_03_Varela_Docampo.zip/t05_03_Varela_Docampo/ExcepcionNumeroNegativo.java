public class ExcepcionNumeroNegativo extends RuntimeException{
    public ExcepcionNumeroNegativo(String msg){
        super(msg);
    }
}