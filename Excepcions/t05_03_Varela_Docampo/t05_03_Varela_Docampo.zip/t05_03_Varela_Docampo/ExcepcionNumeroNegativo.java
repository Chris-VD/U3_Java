public class ExcepcionNumeroNegativo extends Exception{
    public ExcepcionNumeroNegativo(String msg){
        super(msg);
    }
}