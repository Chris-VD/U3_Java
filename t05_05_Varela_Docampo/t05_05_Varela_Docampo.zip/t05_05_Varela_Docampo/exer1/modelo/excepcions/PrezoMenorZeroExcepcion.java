package modelo.excepcions;

public class PrezoMenorZeroExcepcion extends Exception{
    public PrezoMenorZeroExcepcion(String msg){
        super(msg);
    }
}
