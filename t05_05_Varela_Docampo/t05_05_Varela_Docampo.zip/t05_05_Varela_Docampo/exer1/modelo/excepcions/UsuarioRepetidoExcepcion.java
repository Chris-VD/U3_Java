package modelo.excepcions;

public class UsuarioRepetidoExcepcion extends Exception{
    public UsuarioRepetidoExcepcion(String msg){
        super(msg);
    }
}
