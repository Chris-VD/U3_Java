package modelo.excepcions;

public class StockInsuficienteExcepcion extends Exception{
    public StockInsuficienteExcepcion(String msg){
        super(msg);
    }
}
