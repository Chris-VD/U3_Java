package modelo.excepcions;

public class ConstrasinalInvalidoExcepcion extends Exception{
    public ConstrasinalInvalidoExcepcion(String msg){
        super(msg);
    }
}
