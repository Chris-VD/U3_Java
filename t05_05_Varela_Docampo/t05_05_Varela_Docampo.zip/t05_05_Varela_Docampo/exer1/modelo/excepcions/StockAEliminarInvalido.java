package modelo.excepcions;

public class StockAEliminarInvalido extends Exception{
    public StockAEliminarInvalido(String msg){
        super(msg);
    }
}
