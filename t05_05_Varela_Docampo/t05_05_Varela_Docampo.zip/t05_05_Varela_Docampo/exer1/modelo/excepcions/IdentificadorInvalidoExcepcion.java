package modelo.excepcions;

public class IdentificadorInvalidoExcepcion extends Exception{
    public IdentificadorInvalidoExcepcion(String msg){
        super(msg);
    }
}
