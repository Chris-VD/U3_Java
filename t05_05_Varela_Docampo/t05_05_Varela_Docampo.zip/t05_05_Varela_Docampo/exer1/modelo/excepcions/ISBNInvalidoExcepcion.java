package modelo.excepcions;

public class ISBNInvalidoExcepcion extends Exception{
    public ISBNInvalidoExcepcion(String msg){
        super(msg);
    }
}
