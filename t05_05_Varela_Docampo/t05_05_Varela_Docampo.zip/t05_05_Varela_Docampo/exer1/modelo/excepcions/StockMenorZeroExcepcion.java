package modelo.excepcions;

public class StockMenorZeroExcepcion extends Exception{
    public StockMenorZeroExcepcion(String msg){
        super(msg);
    }
}
