package utils;

public enum EnumInstrumentos {
    FRAUTA,
    SAXOFON,
    TROMBON
}
