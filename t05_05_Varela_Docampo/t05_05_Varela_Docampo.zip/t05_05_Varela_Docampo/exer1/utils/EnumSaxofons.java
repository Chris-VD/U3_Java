package utils;

public enum EnumSaxofons {
    SOPRANO,
    ALTO,
    TENOR,
    BARÍTONO
}
