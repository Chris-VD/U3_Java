package utils;

public enum RolesEnum {
    ADMIN,
    CLIENTE
}
