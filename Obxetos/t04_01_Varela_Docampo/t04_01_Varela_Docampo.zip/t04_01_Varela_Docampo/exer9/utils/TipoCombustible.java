package utils;

public enum TipoCombustible{
    DIESEL,
    GASOLINA,
    ELECTRICO
}